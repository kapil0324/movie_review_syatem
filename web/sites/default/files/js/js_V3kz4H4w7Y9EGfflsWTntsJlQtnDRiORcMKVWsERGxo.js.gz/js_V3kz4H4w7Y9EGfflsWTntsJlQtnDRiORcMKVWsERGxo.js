/**
 * @file
 * Global utilities.
 *
 */
(function($, Drupal) {

  'use strict';

  // Drupal.behaviors.movie = {
  //   attach: function(context, settings) {
      // $(".header-filter, .static_ticket_block").click(function(){
      //   $(".sidebar").addClass("open-tab");
      // });
      console.log('kapil');
  //   }
  // };
})(jQuery, Drupal);  ;
